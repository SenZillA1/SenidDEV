# SENID DEVELOPMENT - Professional Portfolio Website

A modern, Apple-inspired portfolio website for SENID DEVELOPMENT featuring a dark green gradient theme, multi-page architecture, and database-driven contact/feedback systems.

## Features

- **Multi-page Architecture**: Home, About Me, Services, Contact, Feedback
- **Apple-style Design**: Clean, elegant interface with smooth animations
- **Dark Green Theme**: Professional branding with gradient effects
- **Database Integration**: PostgreSQL for contact forms and feedback
- **Responsive Design**: Works on desktop and mobile devices
- **Code-based Logo**: SVG logo with 3D effects and gradients

## Quick Start

### Option 1: Run on Replit (Recommended)
1. Fork this project on Replit
2. Click "Run" - everything is pre-configured!
3. Your website will be available at the provided URL

### Option 2: Run Locally

#### Prerequisites
- Node.js (v18 or higher)
- PostgreSQL database

#### Setup Steps

1. **Clone and install dependencies:**
   ```bash
   git clone <your-repo-url>
   cd senid-development
   npm install
   ```

2. **Set up environment variables:**
   ```bash
   cp .env.example .env
   ```
   Edit `.env` with your database credentials:
   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/senid_development
   ```

3. **Set up database:**
   ```bash
   npm run db:push
   ```

4. **Start the application:**
   ```bash
   npm run dev
   ```

5. **Open your browser:**
   ```
   http://localhost:5000
   ```

## Tech Stack

- **Frontend**: React, TypeScript, Tailwind CSS, Wouter (routing)
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Build Tools**: Vite, esbuild
- **UI Components**: shadcn/ui with Radix primitives

## Project Structure

```
├── client/src/           # React frontend
│   ├── components/       # Reusable UI components
│   ├── pages/           # Page components
│   └── lib/             # Utilities and query client
├── server/              # Express backend
├── shared/              # Shared types and schemas
└── attached_assets/     # Images and assets
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run db:push` - Push database schema changes
- `npm run db:studio` - Open database studio (if available)

## Environment Variables

Required for local development:
- `DATABASE_URL` - PostgreSQL connection string
- `NODE_ENV` - Environment mode (development/production)

## Contact

For questions about this project, visit the Contact page or submit feedback through the website.

---

Built with ❤️ by SENID DEVELOPMENT