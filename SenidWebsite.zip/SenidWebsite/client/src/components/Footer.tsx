import { Link } from "wouter";
import Logo from "./Logo";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="mb-4">
              <Logo size="sm" />
            </div>
            <p className="text-gray-400 leading-relaxed mb-6 max-w-md">
              Professional software development solutions that transform your vision into powerful, scalable applications.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-[hsl(122,33%,62%)] transition-colors duration-200">
                <i className="fab fa-linkedin text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-[hsl(122,33%,62%)] transition-colors duration-200">
                <i className="fab fa-github text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-[hsl(122,33%,62%)] transition-colors duration-200">
                <i className="fab fa-twitter text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-[hsl(122,33%,62%)] transition-colors duration-200">
                <i className="fab fa-instagram text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-gray-400">
              <li><Link href="/services" className="hover:text-white transition-colors duration-200">Web Development</Link></li>
              <li><Link href="/services" className="hover:text-white transition-colors duration-200">AI Integration</Link></li>
              <li><Link href="/services" className="hover:text-white transition-colors duration-200">Mobile Apps</Link></li>
              <li><Link href="/services" className="hover:text-white transition-colors duration-200">Custom Systems</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-gray-400">
              <li><Link href="/about" className="hover:text-white transition-colors duration-200">About</Link></li>
              <li><Link href="/services" className="hover:text-white transition-colors duration-200">Services</Link></li>
              <li><Link href="/feedback" className="hover:text-white transition-colors duration-200">Feedback</Link></li>
              <li><Link href="/contact" className="hover:text-white transition-colors duration-200">Contact</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between">
          <p className="text-gray-400 text-sm">
            © 2024 SENID DEVELOPMENT. All rights reserved.
          </p>
          <p className="text-gray-400 text-sm mt-4 md:mt-0">
            Turning Ideas Into Code
          </p>
        </div>
      </div>
    </footer>
  );
}
