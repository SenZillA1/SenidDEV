interface LogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
}

export default function Logo({ size = "md", showText = true }: LogoProps) {
  const logoSizes = {
    sm: { width: 32, height: 32, strokeWidth: 8 },
    md: { width: 48, height: 48, strokeWidth: 12 },
    lg: { width: 128, height: 128, strokeWidth: 24 }
  };

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-5xl md:text-7xl"
  };

  const { width, height, strokeWidth } = logoSizes[size];

  return (
    <div className="flex items-center space-x-3">
      <div className="relative">
        <svg 
          width={width} 
          height={height} 
          viewBox="0 0 100 100" 
          className="drop-shadow-lg"
        >
          <defs>
            <linearGradient id={`logoGradient-${size}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="hsl(122, 55%, 12%)" />
              <stop offset="50%" stopColor="hsl(122, 46%, 18%)" />
              <stop offset="100%" stopColor="hsl(122, 39%, 49%)" />
            </linearGradient>
          </defs>
          
          {/* 3D S Shape */}
          <path
            d="M25 20 
               Q15 20 15 30
               Q15 40 25 40
               L65 40
               Q75 40 75 50
               Q75 60 65 60
               L35 60
               Q25 60 25 70
               Q25 80 35 80
               L75 80"
            fill="none"
            stroke={`url(#logoGradient-${size})`}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeLinejoin="round"
            className="drop-shadow-sm"
          />
          
          {/* Inner highlight for 3D effect */}
          <path
            d="M25 20 
               Q15 20 15 30
               Q15 40 25 40
               L65 40
               Q75 40 75 50
               Q75 60 65 60
               L35 60
               Q25 60 25 70
               Q25 80 35 80
               L75 80"
            fill="none"
            stroke="rgba(255,255,255,0.3)"
            strokeWidth={strokeWidth / 3}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      {showText && (
        <div className="flex flex-col">
          <span className={`font-bold gradient-text ${textSizeClasses[size]}`}>
            SENID
          </span>
          {size === "lg" && (
            <span className="text-xl md:text-2xl text-muted-foreground font-light tracking-wide">
              DEVELOPMENT
            </span>
          )}
        </div>
      )}
    </div>
  );
}
