import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import senidPhoto from "@assets/senid-photo.jpg";

export default function AboutMe() {
  return (
    <div className="min-h-screen pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-light text-gray-900 mb-4">
            About <span className="gradient-text font-semibold">Me</span>
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-[hsl(122,46%,18%)] to-[hsl(122,39%,49%)] mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Professional Developer & Founder of SENID DEVELOPMENT
          </p>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-semibold text-gray-900 mb-6">My Journey</h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  With over 8 years of experience in software development, I founded SENID DEVELOPMENT to bridge the gap between innovative ideas and exceptional digital solutions. My passion lies in crafting clean, efficient code that powers meaningful applications.
                </p>
                <p>
                  From startups to enterprise solutions, I've helped businesses transform their vision into scalable, user-centric applications that drive growth and success. My approach combines technical expertise with a deep understanding of business needs.
                </p>
                <p>
                  I specialize in modern web technologies, AI integration, and creating custom solutions that solve real-world problems. Every project is an opportunity to push boundaries and deliver exceptional results.
                </p>
              </div>
            </div>
            
            <div className="grid sm:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold gradient-text mb-2">50+</div>
                  <div className="text-gray-600">Projects Completed</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold gradient-text mb-2">8+</div>
                  <div className="text-gray-600">Years Experience</div>
                </CardContent>
              </Card>
            </div>
          </div>
          
          <div className="space-y-6">
            <img 
              src={senidPhoto} 
              alt="Senid - Founder & Lead Developer" 
              className="rounded-2xl shadow-2xl w-full max-w-md mx-auto object-cover aspect-square" 
            />
            
            <Card className="bg-gradient-to-br from-[hsl(122,55%,12%)] to-[hsl(122,46%,18%)] text-white">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Core Expertise</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>• React & Next.js</div>
                  <div>• Node.js & Python</div>
                  <div>• AI Integration</div>
                  <div>• Cloud Solutions</div>
                  <div>• Mobile Development</div>
                  <div>• Database Design</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Experience Timeline */}
        <div className="mb-20">
          <h2 className="text-3xl font-light text-center text-gray-900 mb-12">
            Professional <span className="gradient-text font-semibold">Timeline</span>
          </h2>
          
          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-4 h-4 bg-[hsl(122,46%,18%)] rounded-full mt-1"></div>
                <div>
                  <h3 className="font-semibold text-gray-900">2024 - Present</h3>
                  <h4 className="text-lg font-medium text-[hsl(122,46%,18%)]">Founder & Lead Developer</h4>
                  <p className="text-gray-600">Founded SENID DEVELOPMENT, focusing on AI-powered solutions and modern web applications</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-4 h-4 bg-[hsl(122,46%,18%)] rounded-full mt-1"></div>
                <div>
                  <h3 className="font-semibold text-gray-900">2020 - 2024</h3>
                  <h4 className="text-lg font-medium text-[hsl(122,46%,18%)]">Senior Full-Stack Developer</h4>
                  <p className="text-gray-600">Led development teams and architected scalable solutions for enterprise clients</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-4 h-4 bg-[hsl(122,46%,18%)] rounded-full mt-1"></div>
                <div>
                  <h3 className="font-semibold text-gray-900">2018 - 2020</h3>
                  <h4 className="text-lg font-medium text-[hsl(122,46%,18%)]">Software Developer</h4>
                  <p className="text-gray-600">Developed web applications and gained expertise in modern frameworks</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-4 h-4 bg-[hsl(122,46%,18%)] rounded-full mt-1"></div>
                <div>
                  <h3 className="font-semibold text-gray-900">2016 - 2018</h3>
                  <h4 className="text-lg font-medium text-[hsl(122,46%,18%)]">Junior Developer</h4>
                  <p className="text-gray-600">Started professional career, learning best practices and industry standards</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Ready to Work Together?</h2>
          <p className="text-gray-600 mb-8">Let's discuss how I can help bring your ideas to life</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-[hsl(122,46%,18%)] hover:bg-[hsl(122,55%,12%)]">
              <Link href="/contact">Get In Touch</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="/services">View Services</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
