import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertFeedbackSchema, type InsertFeedback, type Feedback } from "@shared/schema";
import { Star } from "lucide-react";

export default function FeedbackPage() {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);

  const form = useForm<InsertFeedback>({
    resolver: zodResolver(insertFeedbackSchema),
    defaultValues: {
      name: "",
      email: "",
      rating: 5,
      comment: "",
    },
  });

  const { data: feedbackData, isLoading } = useQuery<{ success: boolean; feedback: Feedback[] }>({
    queryKey: ["/api/feedback"],
  });

  const submitFeedback = useMutation({
    mutationFn: async (data: InsertFeedback) => {
      const response = await apiRequest("POST", "/api/feedback", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/feedback"] });
      toast({
        title: "Success!",
        description: "Thank you for your feedback!",
      });
      form.reset();
      setShowForm(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit feedback",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertFeedback) => {
    submitFeedback.mutate(data);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < rating ? "text-yellow-400 fill-current" : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-light text-gray-900 mb-4">
            Client <span className="gradient-text font-semibold">Feedback</span>
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-[hsl(122,46%,18%)] to-[hsl(122,39%,49%)] mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            See what our clients have to say about working with SENID DEVELOPMENT
          </p>
        </div>

        {/* Add Feedback Button */}
        <div className="text-center mb-12">
          <Button
            onClick={() => setShowForm(!showForm)}
            size="lg"
            className="bg-[hsl(122,46%,18%)] hover:bg-[hsl(122,55%,12%)]"
          >
            {showForm ? "Cancel" : "Share Your Experience"}
          </Button>
        </div>

        {/* Feedback Form */}
        {showForm && (
          <Card className="max-w-2xl mx-auto mb-16">
            <CardHeader>
              <CardTitle>Share Your Feedback</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your full name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="your.email@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="rating"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rating</FormLabel>
                        <Select onValueChange={(value) => field.onChange(Number(value))} defaultValue={field.value.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a rating" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="5">⭐⭐⭐⭐⭐ Excellent</SelectItem>
                            <SelectItem value="4">⭐⭐⭐⭐ Very Good</SelectItem>
                            <SelectItem value="3">⭐⭐⭐ Good</SelectItem>
                            <SelectItem value="2">⭐⭐ Fair</SelectItem>
                            <SelectItem value="1">⭐ Poor</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="comment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Comment</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Share your experience working with us..."
                            rows={4}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full bg-[hsl(122,46%,18%)] hover:bg-[hsl(122,55%,12%)]"
                    disabled={submitFeedback.isPending}
                  >
                    {submitFeedback.isPending ? "Submitting..." : "Submit Feedback"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        )}

        {/* Feedback List */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2 mb-4">
                    <Skeleton className="w-6 h-6 rounded-full" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4 mb-4" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))
          ) : feedbackData?.feedback && feedbackData.feedback.length > 0 ? (
            feedbackData.feedback.map((feedback) => (
              <Card key={feedback.id} className="hover:shadow-lg transition-shadow duration-200">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2 mb-4">
                    <div className="flex">{renderStars(feedback.rating)}</div>
                    <span className="text-sm text-gray-500">({feedback.rating}/5)</span>
                  </div>
                  <p className="text-gray-700 mb-4 leading-relaxed">"{feedback.comment}"</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <span className="font-medium">{feedback.name}</span>
                    <span>{new Date(feedback.createdAt).toLocaleDateString()}</span>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-gray-500 text-lg">No feedback yet. Be the first to share your experience!</p>
            </div>
          )}
        </div>

        {/* Statistics */}
        {feedbackData?.feedback && feedbackData.feedback.length > 0 && (
          <div className="mt-16 text-center">
            <h2 className="text-2xl font-semibold text-gray-900 mb-8">Client Satisfaction</h2>
            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold gradient-text mb-2">
                    {feedbackData.feedback.length}
                  </div>
                  <div className="text-gray-600">Total Reviews</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold gradient-text mb-2">
                    {(feedbackData.feedback.reduce((sum, f) => sum + f.rating, 0) / feedbackData.feedback.length).toFixed(1)}
                  </div>
                  <div className="text-gray-600">Average Rating</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold gradient-text mb-2">
                    {Math.round((feedbackData.feedback.filter(f => f.rating >= 4).length / feedbackData.feedback.length) * 100)}%
                  </div>
                  <div className="text-gray-600">Satisfied Clients</div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
