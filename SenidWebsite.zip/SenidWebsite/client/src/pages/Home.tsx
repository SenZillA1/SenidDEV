import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowDown, MessageCircle, Sparkles } from "lucide-react";
import Logo from "@/components/Logo";

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="min-h-screen hero-gradient flex items-center justify-center relative overflow-hidden">
        {/* Background Particles */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/20 rounded-full animate-float"></div>
          <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-white/30 rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
          <div className="absolute bottom-1/4 left-1/3 w-3 h-3 bg-white/10 rounded-full animate-float" style={{ animationDelay: '4s' }}></div>
          <div className="absolute top-2/3 right-1/4 w-1 h-1 bg-white/40 rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
        </div>
        
        <div className="text-center text-white z-10 px-4 max-w-4xl mx-auto">
          {/* Company Logo */}
          <div className="mb-8 animate-fade-in">
            <div className="flex flex-col items-center mb-6">
              <Logo size="lg" showText={false} />
              <div className="mt-4">
                <h1 className="text-5xl md:text-7xl font-light mb-2 gradient-text">SENID</h1>
                <p className="text-xl md:text-2xl text-white/80 font-light tracking-wide">DEVELOPMENT</p>
              </div>
            </div>
          </div>
          
          <h2 className="text-2xl md:text-4xl font-light mb-8 text-white/90 animate-slide-up" style={{ animationDelay: '0.3s' }}>
            Turning Ideas Into Code
          </h2>
          
          <p className="text-lg md:text-xl text-white/70 mb-12 max-w-2xl mx-auto leading-relaxed animate-slide-up" style={{ animationDelay: '0.6s' }}>
            Professional software development solutions that transform your vision into powerful, scalable applications
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up" style={{ animationDelay: '0.9s' }}>
            <Button asChild size="lg" className="bg-white text-[hsl(122,55%,12%)] hover:bg-gray-100 shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300">
              <Link href="/services">
                Explore Services
              </Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="group border-2 border-white bg-transparent text-white hover:bg-white hover:text-[hsl(122,55%,12%)] shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 relative overflow-hidden"
              onClick={() => {
                const contactSection = document.getElementById('contact-section');
                if (contactSection) {
                  contactSection.scrollIntoView({ behavior: 'smooth' });
                } else {
                  window.location.href = '/contact';
                }
              }}
            >
              <span className="flex items-center gap-2 relative z-10 text-white group-hover:text-[hsl(122,55%,12%)] transition-colors duration-300">
                <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform duration-200" />
                <span className="font-medium tracking-wide">Get In Touch</span>
                <Sparkles className="w-4 h-4 group-hover:rotate-12 transition-transform duration-200" />
              </span>
              
              {/* Animated background effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-white/5 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 ease-out"></div>
            </Button>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ArrowDown className="text-white/60 hover:text-white transition-colors duration-200 h-8 w-8" />
        </div>
      </section>

      {/* Quick Overview Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-light text-gray-900 mb-4">
              Why Choose <span className="gradient-text font-semibold">SENID</span>?
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[hsl(122,46%,18%)] to-[hsl(122,39%,49%)] mx-auto mb-8"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-gradient-to-br from-[hsl(122,39%,49%)] to-[hsl(122,46%,18%)] rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-code text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Expert Development</h3>
              <p className="text-gray-600">8+ years of experience in cutting-edge technologies</p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-gradient-to-br from-[hsl(122,39%,49%)] to-[hsl(122,46%,18%)] rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-users text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Client-Focused</h3>
              <p className="text-gray-600">Tailored solutions that meet your unique requirements</p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-gradient-to-br from-[hsl(122,39%,49%)] to-[hsl(122,46%,18%)] rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-rocket text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Future-Ready</h3>
              <p className="text-gray-600">Modern, scalable solutions built for tomorrow</p>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Contact Section */}
      <section id="contact-section" className="py-20 bg-gradient-to-br from-gray-900 to-[hsl(122,55%,12%)] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl md:text-4xl font-light mb-4">
              Ready to Start Your <span className="text-[hsl(122,33%,62%)] font-semibold">Project</span>?
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[hsl(122,33%,62%)] to-[hsl(122,39%,49%)] mx-auto mb-8"></div>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed mb-12">
              Let's discuss your ideas and turn them into powerful digital solutions
            </p>
            
            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="text-center">
                <div className="w-16 h-16 bg-[hsl(122,33%,62%)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-envelope text-2xl text-white"></i>
                </div>
                <h3 className="text-lg font-semibold mb-2">Email Us</h3>
                <p className="text-gray-300">hello@seniddevelopment.com</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-[hsl(122,33%,62%)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-phone text-2xl text-white"></i>
                </div>
                <h3 className="text-lg font-semibold mb-2">Call Us</h3>
                <p className="text-gray-300">+1 (555) 123-4567</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-[hsl(122,33%,62%)] rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-calendar text-2xl text-white"></i>
                </div>
                <h3 className="text-lg font-semibold mb-2">Schedule</h3>
                <p className="text-gray-300">Free Consultation</p>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-[hsl(122,33%,62%)] text-white hover:bg-[hsl(122,39%,49%)] shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                <Link href="/contact">
                  Send Message
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-2 border-[hsl(122,33%,62%)] text-[hsl(122,33%,62%)] hover:bg-[hsl(122,33%,62%)] hover:text-white shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                <Link href="/services">
                  View Services
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
