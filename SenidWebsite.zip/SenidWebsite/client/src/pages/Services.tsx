import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";

export default function Services() {
  return (
    <div className="min-h-screen pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-light text-gray-900 mb-4">
            Our <span className="gradient-text font-semibold">Services</span>
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-[hsl(122,46%,18%)] to-[hsl(122,39%,49%)] mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Comprehensive development solutions tailored to your business needs
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {/* Web Development */}
          <Card className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-gradient-to-br from-[hsl(122,39%,49%)] to-[hsl(122,46%,18%)] rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className="fas fa-code text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Web Development</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Modern, responsive websites and web applications built with the latest technologies for optimal performance.
              </p>
              <div className="text-sm text-gray-500 space-y-1">
                <div>• React & Next.js</div>
                <div>• Vue.js & Nuxt</div>
                <div>• Progressive Web Apps</div>
                <div>• E-commerce Solutions</div>
              </div>
            </CardContent>
          </Card>

          {/* AI Integration */}
          <Card className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-gradient-to-br from-[hsl(122,39%,49%)] to-[hsl(122,46%,18%)] rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className="fas fa-brain text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">AI Integration</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Intelligent solutions that leverage machine learning and AI to enhance your applications and business processes.
              </p>
              <div className="text-sm text-gray-500 space-y-1">
                <div>• ChatGPT Integration</div>
                <div>• Computer Vision</div>
                <div>• Natural Language Processing</div>
                <div>• Predictive Analytics</div>
              </div>
            </CardContent>
          </Card>

          {/* Mobile Apps */}
          <Card className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-gradient-to-br from-[hsl(122,39%,49%)] to-[hsl(122,46%,18%)] rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className="fas fa-mobile-alt text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Mobile Apps</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Native and cross-platform mobile applications that deliver exceptional user experiences across all devices.
              </p>
              <div className="text-sm text-gray-500 space-y-1">
                <div>• React Native</div>
                <div>• Flutter</div>
                <div>• iOS & Android</div>
                <div>• App Store Optimization</div>
              </div>
            </CardContent>
          </Card>

          {/* Custom Systems */}
          <Card className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-gradient-to-br from-[hsl(122,39%,49%)] to-[hsl(122,46%,18%)] rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className="fas fa-cogs text-2xl text-white"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Custom Systems</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Bespoke software solutions designed specifically for your unique business requirements and workflows.
              </p>
              <div className="text-sm text-gray-500 space-y-1">
                <div>• CRM & ERP Systems</div>
                <div>• API Development</div>
                <div>• Database Architecture</div>
                <div>• Cloud Integration</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Development Process */}
        <div className="mb-20">
          <h2 className="text-3xl font-light text-center text-gray-900 mb-12">
            Development <span className="gradient-text font-semibold">Process</span>
          </h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-[hsl(122,46%,18%)] text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">1</div>
              <h3 className="font-semibold text-gray-900 mb-2">Discovery</h3>
              <p className="text-gray-600 text-sm">Understanding your needs and defining project scope</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-[hsl(122,46%,18%)] text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">2</div>
              <h3 className="font-semibold text-gray-900 mb-2">Design</h3>
              <p className="text-gray-600 text-sm">Creating wireframes and visual designs</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-[hsl(122,46%,18%)] text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">3</div>
              <h3 className="font-semibold text-gray-900 mb-2">Development</h3>
              <p className="text-gray-600 text-sm">Building your solution with cutting-edge technology</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-[hsl(122,46%,18%)] text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">4</div>
              <h3 className="font-semibold text-gray-900 mb-2">Launch</h3>
              <p className="text-gray-600 text-sm">Deployment and ongoing support</p>
            </div>
          </div>
        </div>

        {/* Pricing Tiers */}
        <div className="mb-20">
          <h2 className="text-3xl font-light text-center text-gray-900 mb-12">
            Pricing <span className="gradient-text font-semibold">Options</span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="relative">
              <CardContent className="p-8">
                <h3 className="text-2xl font-semibold text-gray-900 mb-2">Starter</h3>
                <div className="text-3xl font-bold text-[hsl(122,46%,18%)] mb-4">$2,500</div>
                <p className="text-gray-600 mb-6">Perfect for small projects and MVPs</p>
                <ul className="space-y-2 text-sm text-gray-600 mb-8">
                  <li>• Single web application</li>
                  <li>• Responsive design</li>
                  <li>• Basic features</li>
                  <li>• 1 month support</li>
                </ul>
                <Button className="w-full bg-[hsl(122,46%,18%)] hover:bg-[hsl(122,55%,12%)]">
                  Get Started
                </Button>
              </CardContent>
            </Card>

            <Card className="relative border-[hsl(122,46%,18%)] border-2">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-[hsl(122,46%,18%)] text-white px-4 py-1 rounded-full text-sm">
                Most Popular
              </div>
              <CardContent className="p-8">
                <h3 className="text-2xl font-semibold text-gray-900 mb-2">Professional</h3>
                <div className="text-3xl font-bold text-[hsl(122,46%,18%)] mb-4">$7,500</div>
                <p className="text-gray-600 mb-6">Ideal for growing businesses</p>
                <ul className="space-y-2 text-sm text-gray-600 mb-8">
                  <li>• Full-stack application</li>
                  <li>• Advanced features</li>
                  <li>• API integrations</li>
                  <li>• 3 months support</li>
                </ul>
                <Button className="w-full bg-[hsl(122,46%,18%)] hover:bg-[hsl(122,55%,12%)]">
                  Get Started
                </Button>
              </CardContent>
            </Card>

            <Card className="relative">
              <CardContent className="p-8">
                <h3 className="text-2xl font-semibold text-gray-900 mb-2">Enterprise</h3>
                <div className="text-3xl font-bold text-[hsl(122,46%,18%)] mb-4">Custom</div>
                <p className="text-gray-600 mb-6">Tailored solutions for large organizations</p>
                <ul className="space-y-2 text-sm text-gray-600 mb-8">
                  <li>• Custom architecture</li>
                  <li>• Scalable infrastructure</li>
                  <li>• Priority support</li>
                  <li>• Ongoing maintenance</li>
                </ul>
                <Button variant="outline" className="w-full border-[hsl(122,46%,18%)] text-[hsl(122,46%,18%)] hover:bg-[hsl(122,46%,18%)] hover:text-white">
                  Contact Us
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Ready to Get Started?</h2>
          <p className="text-gray-600 mb-8">Let's discuss your project and find the perfect solution</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-[hsl(122,46%,18%)] hover:bg-[hsl(122,55%,12%)]">
              <Link href="/contact">Start Your Project</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="/feedback">View Client Reviews</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
