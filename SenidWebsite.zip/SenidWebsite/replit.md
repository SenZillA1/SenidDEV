# SENID Development - Replit Project Documentation

## Overview

This is a full-stack web application for SENID Development, a professional software development company. The application serves as a business website showcasing services, handling contact forms, and collecting customer feedback. It's built with a modern React frontend and Express.js backend, using PostgreSQL for data persistence.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom brand colors and animations
- **State Management**: TanStack Query (React Query) for server state
- **Forms**: React Hook Form with Zod validation
- **Animations**: Framer Motion for page transitions
- **Logo**: Code-based SVG logo with dark green gradient theme

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Style**: RESTful API endpoints
- **Database**: PostgreSQL with Drizzle ORM and Neon serverless driver
- **Data Storage**: DatabaseStorage class implementing full CRUD operations
- **Development**: Vite integration for hot module replacement

### Build System
- **Frontend Build**: Vite with React plugin
- **Backend Build**: esbuild for production bundling
- **Development**: tsx for TypeScript execution
- **CSS Processing**: PostCSS with Tailwind CSS and Autoprefixer

## Key Components

### Database Schema (shared/schema.ts)
- **Users Table**: Basic user authentication structure
- **Contacts Table**: Contact form submissions with name, email, message, and timestamp
- **Feedback Table**: Customer feedback with rating (1-5) and comments
- **Validation**: Zod schemas for type-safe data validation

### API Endpoints (server/routes.ts)
- `POST /api/contact` - Contact form submission
- `POST /api/feedback` - Feedback submission
- Error handling with proper HTTP status codes and validation

### Frontend Pages
- **Home**: Hero section with company branding and call-to-action
- **About Me**: Personal/company information and statistics
- **Services**: Service offerings with detailed descriptions
- **Contact**: Contact form with real-time validation
- **Feedback**: Feedback submission and display system

### UI Components
- **Navigation**: Responsive navigation with mobile menu
- **Logo**: Brand logo component with size variants
- **PageTransition**: Smooth page transitions using Framer Motion
- **Footer**: Company information and social links

## Data Flow

1. **User Interaction**: Users interact with React components
2. **Form Validation**: Client-side validation using Zod schemas
3. **API Requests**: TanStack Query manages HTTP requests to Express backend
4. **Server Processing**: Express routes handle business logic and validation
5. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
6. **Response Handling**: Success/error feedback via toast notifications

## External Dependencies

### Frontend Dependencies
- **React Ecosystem**: React, React DOM, React Hook Form
- **UI Libraries**: Radix UI primitives, Lucide React icons
- **Utilities**: clsx, tailwind-merge, class-variance-authority
- **Date Handling**: date-fns
- **Animations**: Framer Motion, embla-carousel-react

### Backend Dependencies
- **Server**: Express.js with middleware for JSON parsing
- **Database**: Drizzle ORM with @neondatabase/serverless driver
- **Validation**: Zod for schema validation
- **Session**: connect-pg-simple for PostgreSQL session storage
- **Development**: tsx, esbuild for TypeScript support

### Development Tools
- **Build**: Vite, esbuild, TypeScript compiler
- **Database**: Drizzle Kit for migrations and schema management
- **Styling**: Tailwind CSS, PostCSS, Autoprefixer
- **Replit Integration**: Cartographer plugin, runtime error overlay

## Deployment Strategy

### Development Mode
- Frontend served by Vite dev server with HMR
- Backend runs with tsx for TypeScript execution
- Database migrations handled by Drizzle Kit
- Error overlay for debugging in Replit environment

### Production Build
1. Frontend builds to `dist/public` directory
2. Backend bundles to `dist/index.js` with esbuild
3. Static files served by Express in production
4. Database requires PostgreSQL connection via DATABASE_URL

### Environment Requirements
- **DATABASE_URL**: PostgreSQL connection string
- **NODE_ENV**: Environment mode (development/production)
- **REPL_ID**: Replit-specific identifier for development features

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

- July 01, 2025: Initial setup with Apple-inspired design and dark green gradient theme
- July 01, 2025: Replaced image logo with code-based SVG logo featuring 3D "S" emblem
- July 01, 2025: Added PostgreSQL database with Neon serverless driver
- July 01, 2025: Fixed "Get In Touch" button with smooth scroll to contact section
- July 01, 2025: Added quick contact section to home page with contact information